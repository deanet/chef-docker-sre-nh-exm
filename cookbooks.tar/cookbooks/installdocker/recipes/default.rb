#
# Cookbook:: installdocker
# Recipe:: default
#
# Copyright:: 2022, The Authors, All Rights Reserved.

## install and start docker
docker_service 'default' do
  action [:create, :start]
end

